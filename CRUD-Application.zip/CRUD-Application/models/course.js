const mongoose = require("mongoose");

const schemaObj = {
    name: { type: String, required: true },
    code: { type: String, required: true }
};

// Define the schema with `new` for clarity, and enable timestamps
const mongooseSchema = new mongoose.Schema(schemaObj, { timestamps: true });

module.exports = mongoose.model("Course", mongooseSchema);
