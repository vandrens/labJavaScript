require("dotenv").config();
// Global configurations object contains Application Level variables such as:
// client secrets, passwords, connection strings, and misc
const configurations = {
  ConnectionStrings: {
    MongoDB: "mongodb+srv://vandreswaab:vandre123@cluster0.hx10u.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
  },
  Authentication: {
    facebook: {
      ClientId: "1012377013909111",
      ClientSecret: "40d121f47fd72b6f9ee419e5c8394201",
      CallbackUrl: "http://localhost:3000/facebook/callback"
    },
  },
};
module.exports = configurations;
